package examplemodel.editorcustomizations;

import library.LibraryPackage;

import org.eclipse.core.databinding.observable.value.IObservableValue;
import org.eclipse.emf.databinding.EMFDataBindingContext;
import org.eclipse.emf.databinding.edit.EMFEditObservables;
import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecp.editor.mecontrols.AbstractMEControl;
import org.eclipse.emf.edit.provider.IItemPropertyDescriptor;
import org.eclipse.jface.action.Action;
import org.eclipse.jface.databinding.swt.ISWTObservableValue;
import org.eclipse.jface.databinding.swt.SWTObservables;
import org.eclipse.jface.layout.GridDataFactory;
import org.eclipse.jface.layout.GridLayoutFactory;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.program.Program;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Text;

public class EMailMEControl extends AbstractMEControl{


	private Label labelWidgetImage;
	private Text text;
	private EAttribute attribute;
	private EMFDataBindingContext dbc;

	public EMailMEControl() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public int canRender(IItemPropertyDescriptor arg0, EObject arg1) {
		Object feature = arg0.getFeature(arg1);
		if (feature.equals(LibraryPackage.eINSTANCE.getWriter_EMail())) {
			return 2;
		}
		return DO_NOT_RENDER;
	}

	@Override
	public Control createControl(Composite parent, int style) {

		Composite composite = getToolkit().createComposite(parent, style);
		GridLayout gridLayout = new GridLayout(2, false);
		composite.setLayout(gridLayout);
		GridDataFactory.fillDefaults().align(SWT.FILL, SWT.CENTER).grab(true,
				true).applyTo(composite);
		
		Object feature = getItemPropertyDescriptor().getFeature(getModelElement());
		attribute = (EAttribute) feature;
		
		composite = getToolkit().createComposite(composite, style);
		composite.setBackgroundMode(SWT.INHERIT_FORCE);
		GridLayoutFactory.fillDefaults().numColumns(2).spacing(2, 0).applyTo(composite);
		GridDataFactory.fillDefaults().grab(true, false).applyTo(composite);

		

		text = getToolkit().createText(composite, new String(), style | SWT.SINGLE | SWT.BORDER);
		text.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true));
		if (!getItemPropertyDescriptor().canSetProperty(getModelElement())) {
			text.setEditable(false);
		}
		IObservableValue model = EMFEditObservables.observeValue(getEditingDomain(), getModelElement(), attribute);
		dbc = new EMFDataBindingContext();
		ISWTObservableValue observeText = SWTObservables.observeText(text, SWT.FocusOut);
		dbc.bindValue(observeText, model, null, null);
		
		

		GridDataFactory.fillDefaults().align(SWT.FILL, SWT.CENTER).grab(true,
				true).applyTo(text);
		final Action mail = new Action("Send email", SWT.PUSH) {

			@Override
			public void run() {
				String email = text.getText();
				Program.launch("mailto:" + email);
			}

		};
		Button button = new Button(composite, SWT.PUSH);
		button.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				mail.run();
			}

		});
		button.setLayoutData(new GridData(SWT.LEFT, SWT.CENTER, false, false));
		button.setText("send Mail");

		return composite;
	}

	@Override
	public void dispose() {
		dbc.dispose();
		super.dispose();
	}

}
