package examplemodel.navigatorcustomizations;

import library.Library;

import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecp.common.util.ModelElementOpener;
import org.eclipse.emf.ecp.common.utilities.DefaultLabelProvider;
import org.eclipse.jface.dialogs.Dialog;
import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Display;

public class LibraryOpener implements ModelElementOpener {

	public LibraryOpener() {
		// TODO Auto-generated constructor stub
	}

	public int canOpen(EObject eObject) {
		// Comment this in to register the custom library opener
		// if (eObject instanceof Library) {
		// return 2;
		// }
		return DONOTOPEN;
	}

	public void openModelElement(final EObject library) {
		Dialog messageBox = new Dialog(Display.getDefault().getActiveShell()) {

			@Override
			protected Control createDialogArea(Composite parent) {
				GridData data = new GridData(SWT.CENTER, SWT.CENTER, true, true);
				Composite area = new Composite(parent, SWT.NONE);
				area.setLayout(new GridLayout());
				area.setLayoutData(data);

				TableViewer viewer = new TableViewer(parent);
				viewer.setLabelProvider(new DefaultLabelProvider());
				viewer.add(((Library) library).getBooks().toArray());
				return area;
			}

		};
		messageBox.open();

	}

}
